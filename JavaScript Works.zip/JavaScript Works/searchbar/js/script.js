$(document).ready(function(){
    $("li").each(function(){
        var caps=$(this).html().toUpperCase();
        $(this).html(caps);
    });
});
function search(){
    var x, filter, ul, li, value, i;
    x = document.getElementById("myinput");
    filter = x.value.toUpperCase();
    ul = document.getElementById("output");
    li = ul.getElementsByTagName("li");
    len = li.length;
    for(i=0;i<len;i++){
        value = li[i].innerText.toUpperCase();
        index = value.indexOf(filter);
        if(index!=-1){
            li[i].style.display = "";
            var value1 = value.substring(0,index)+'<span>'+value.substring(index,index+filter.length)+'</span>'+value.substring(index+filter.length);
            li[i].innerHTML = value1;
        }
        else{
            li[i].style.display = "none";
        }
    }
}
