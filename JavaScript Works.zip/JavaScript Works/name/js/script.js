function pyramid(){
    document.getElementById('content').innerHTML="";
    var x= document.getElementById('input').value;
    len = x.length;
    for(i=1; i<=len; i++){
        let y=x.slice(0,i);
        $("#content").append("<div style='color:red'>"+y+"</div>");
    }
}




