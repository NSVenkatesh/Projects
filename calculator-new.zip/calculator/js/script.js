$(document).ready(function(){
    $("#f").click(function(){
        $(".hide").toggle();
    });
});
function clr(){
    $('#res').val("");
}
function del(){
    a=$('#res').val();
    b=a.slice(0,length-1);
    $("#res").val(b);
}
function input(a){
    var y=$("#res").val();
    var x=$(a).val();
    $("#res").val(y+x);
}
function operator(y){
    x=$("#res").val();
    $("#res").val("");
    o=y;
}
function solve(){
    y=$("#res").val();
    if(o=="+"){
        $('#res').val(parseFloat(x)+parseFloat(y));
    }
    else if(o=="-"){
        $('#res').val(parseFloat(x)-parseFloat(y));
    }
    else if(o=="*"){
        $('#res').val(parseFloat(x)*parseFloat(y));
    }
    else if(o=="/"){
        $('#res').val(parseFloat(x)/parseFloat(y));
    }
    else if(o=="%"){
        $('#res').val(parseFloat(x)%parseFloat(y));
    }
    else if(o=="**"){
        $('#res').val(parseFloat(x)**parseFloat(y));
    }
}