data=[
    {
        "name": "POCO",
        "star": "4.6 ★",
        "rating": "30,000",
        "review": "5,000",
        "img": "img/pocom3.jpeg",
        "price": "15,000",
        "specification": ["4 GB RAM | 64 GB ROM | Expandable Upto 256 GB","16.51 cm (6.5 inch) FHD+ Display","4500 mAh Battery", "MediaTek Helio G35 Processor", "1 Year Warranty for Mobile and 6 Months for Accessories"]
    },
    {
        "name": "MI",
        "star": "4.4 ★",
        "rating": "53,300",
        "review": "15,560",
        "price": "24,999",
        "img": "img/mi.jpeg",
        "specification": ["4 GB RAM | 64 GB ROM | Expandable Upto 256 GB","16.51 cm (6.5 inch) FHD+ Display","4500 mAh Battery", "MediaTek Helio G35 Processor", "1 Year Warranty for Mobile and 6 Months for Accessories"]
    },
    {
        "name": "REALME",
        "star": "4.2 ★",
        "rating": "32,105",
        "review": "5,459",
        "price": "14,999",
        "img": "img/realme.jpeg",
        "specification": ["4 GB RAM | 64 GB ROM | Expandable Upto 256 GB","16.51 cm (6.5 inch) FHD+ Display","4500 mAh Battery", "MediaTek Helio G35 Processor", "1 Year Warranty for Mobile and 6 Months for Accessories"]
    },
    {
        "name": "APPLE",
        "star": "4.7 ★",
        "rating": "53,457",
        "review": "22,040",
        "price": "1,10,000",
        "img": "img/apple.jpeg",
        "specification": ["4 GB RAM | 64 GB ROM | Expandable Upto 256 GB","16.51 cm (6.5 inch) FHD+ Display","4500 mAh Battery", "MediaTek Helio G35 Processor", "1 Year Warranty for Mobile and 6 Months for Accessories"]
    },
    {
        "name": "NOKIA",
        "star": "4.9 ★",
        "rating": "38,454",
        "review": "15,356",
        "img": "img/nokia.jpeg",
        "price": "18,000",
        "specification": ["4 GB RAM | 64 GB ROM | Expandable Upto 256 GB","16.51 cm (6.5 inch) FHD+ Display","4500 mAh Battery", "MediaTek Helio G35 Processor", "1 Year Warranty for Mobile and 6 Months for Accessories"]
    },
    {
        "name": "SAMSUNG",
        "star": "4.3 ★",
        "rating": "10,320",
        "review": "2,472",
        "img": "img/samsung.jpeg",
        "price": "35,999",
        "specification": ["4 GB RAM | 64 GB ROM | Expandable Upto 256 GB","16.51 cm (6.5 inch) FHD+ Display","4500 mAh Battery", "MediaTek Helio G35 Processor", "1 Year Warranty for Mobile and 6 Months for Accessories"]
    }
]