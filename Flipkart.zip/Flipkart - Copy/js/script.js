$(document).ready(function(){
    $("#ram").click(function(){
        $("#hide-r").toggle();
    });
    $("#brand").click(function(){
        $("#hide-b").toggle();
    });
    $("#rating").click(function(){
        $("#hide-rt").toggle();
    });
    $("#internal").click(function(){
        $("#hide-is").toggle();
    });
    $("#battery").click(function(){
        $("#hide-bt").toggle();
    });
    $("#os").click(function(){
        $("#hide-os").toggle();
    });
    $("#network").click(function(){
        $("#hide-nt").toggle();
    });
    $("#screen").click(function(){
        $("#hide-ss").toggle();
    });
    $("#sim").click(function(){
        $("#hide-st").toggle();
    });
    $("#pcam").click(function(){
        $("#hide-pc").toggle();
    });
    $("#scam").click(function(){
        $("#hide-sc").toggle();
    });
    $("#offers").click(function(){
        $("#hide-o").toggle();
    });
    $("#processor").click(function(){
        $("#hide-pb").toggle();
    });
    $("#special").click(function(){
        $("#hide-spec").toggle();
    });
    $("#resolution").click(function(){
        $("#hide-rtype").toggle();
    });
    $("#type").click(function(){
        $("#hide-type").toggle();
    });
    $("#osv").click(function(){
        $("#hide-osv").toggle();
    });
    $("#avail").click(function(){
        $("#hide-av").toggle();
    });
    $("#cs").click(function(){
        $("#hide-cs").toggle();
    });
    $("#feat").click(function(){
        $("#hide-ft").toggle();
    });
    $("#nc").click(function(){
        $("#hide-nc").toggle();
    });
    $("#budget").click(function(){
        $("#hide-bd").toggle();
    });
    $("#gst").click(function(){
        $("#hide-gst").toggle();
    });
});
$(document).scroll(function() {     
    var scroll = $(window).scrollTop();
    if (scroll > 0) {
        $("#header").addClass("active");
    }
    else {
        $("#header").removeClass("active");
    }
});
$(document).ready(function(){
    var clonex = $(".container");
    for(i=0; i<data.length; i++){
        var cloney = clonex.clone();
        currentdata = data[i];
        $(cloney).appendTo(".right");
        $(cloney).find(".mname").html(currentdata.name);
        $(cloney).find(".mimage").attr('src',currentdata.img);
        $(cloney).find(".star").html(currentdata.star);
        $(cloney).find(".rate").html(currentdata.price);
        $(cloney).find(".rating").html(currentdata.rating);
        $(cloney).find(".review").html(currentdata.review);
    }
});

